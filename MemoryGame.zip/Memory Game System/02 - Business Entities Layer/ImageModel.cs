﻿
namespace JohnBryce
{
    public class ImageModel
    {
        public int id { get; set; }
        public string imageFileName { get; set; }
    }
}
