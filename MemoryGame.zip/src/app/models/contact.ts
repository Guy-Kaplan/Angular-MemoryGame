
export class Contact{

    public constructor(
        public id?: number,
        public phone?: string,
        public email?: string,
        public message?: string,

    ) { }
    
}