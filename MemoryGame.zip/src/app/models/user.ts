
export class User{

    public constructor(
        public id?: number,
        public fullName?: string,
        public userName?: string,
        public password?: string,
        public email?: string,
        public birthDate?: Date,


    ) { }
    
}