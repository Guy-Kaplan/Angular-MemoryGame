
export class Image{

    public constructor(
        public id?: number,
        public imageFileName?: string,
        
    ) { }
    
}