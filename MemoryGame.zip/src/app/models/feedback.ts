
export class Feedback {

    public constructor(
        public id?: number,
        public userID?: number,
        public dateAdded?: string,
        public feedback?: string,

    ) { }
    
}